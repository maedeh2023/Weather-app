const apiKey = 'f2edea16a9b95535ce4c80818f99bbf6'; 
const currentWeatherUrl = 'https://api.openweathermap.org/data/2.5/weather';
const forecastUrl = 'https://api.openweathermap.org/data/2.5/forecast';

document.getElementById('city-select').addEventListener('change', (event) => {
    const city = event.target.value;
    if (city) {
        fetchCurrentWeather(city);
        fetchWeatherForecast(city);
    } else {
        clearWeatherInfo();
    }
});

function fetchCurrentWeather(city) {
    const url = `${currentWeatherUrl}?q=${city}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                document.getElementById('location').style.color = 'gray';
                document.getElementById('location').style.textAlign = 'center';  
                document.getElementById('location').textContent = data.name;
                document.getElementById('temperature').textContent = `${Math.round(data.main.temp)}°`;

                const humidity = data.main.humidity; 
                const windSpeed = data.wind.speed; 

                document.getElementById('humidity').textContent = `${humidity}%`;
                document.getElementById('wind-speed').textContent = `${windSpeed} m/s`;

                const weatherCondition = data.weather[0].main.toLowerCase(); 
                const weatherImage = document.getElementById('weather-image');

                switch (weatherCondition) {
                    case 'clear':
                    case 'sunny':
                        weatherImage.src = 'assets/img/01_sunny_color.png'; 
                        break;
                    case 'rain':
                    case 'drizzle':
                        weatherImage.src = 'assets/img/11_heavy_rain_color.png'; 
                        break;
                    case 'clouds':
                        weatherImage.src = 'assets/img/03_cloud_color.png'; 
                        break;
                    case 'snow':
                        weatherImage.src = 'assets/img/22_snow_color.png'; 
                        break;
                    case 'thunderstorm':
                        weatherImage.src = 'assets/img/14_thunderstorm_color.png'; 
                        break;
                    default:
                        weatherImage.src = 'assets/img'; 
                        break;
                }
                
                weatherImage.style.display = weatherImage.src ? 'block' : 'none';
            } else {
                clearWeatherInfo();
                alert('City not found. Please select a valid city.');
            }
        });
}

function fetchWeatherForecast(city) {
    const url = `${forecastUrl}?q=${city}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.cod === "200") {
                const dayElements = ["day1", "day2", "day3", "day4", "day5"];
                const weatherImages = ["img1", "img2", "img3", "img4", "img5"];
                const temperatures = ["temp1", "temp2", "temp3", "temp4", "temp5"];

                const today = new Date();
                const persianWeekdays = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه"];


                for (let i = 0; i < 5; i++) {
                    const forecast = data.list[i * 8]; // Get the forecast for the same time each day
                    const temperature = Math.round(forecast.main.temp);
                    const weatherCondition = forecast.weather[0].main.toLowerCase();
                    const weatherImage = document.getElementById(weatherImages[i]);

                    // Set the temperature
                    document.getElementById(temperatures[i]).textContent = `${temperature}°`;

                    // Set image
                    switch (weatherCondition) {
                        case 'clear':
                        case 'sunny':
                            weatherImage.src = 'assets/img/01_sunny_color.png'; 
                            break;
                        case 'rain':
                        case 'drizzle':
                            weatherImage.src = 'assets/img/11_heavy_rain_color.png'; 
                            break;
                        case 'clouds':
                            weatherImage.src = 'assets/img/03_cloud_color.png'; 
                            break;
                        case 'snow':
                            weatherImage.src = 'assets/img/22_snow_color.png'; 
                            break;
                        case 'thunderstorm':
                            weatherImage.src = 'assets/img/14_thunderstorm_color.png'; 
                            break;
                        default:
                            weatherImage.src = 'assets/img'; 
                            break;
                    }

                    document.getElementById(dayElements[i]).textContent = persianWeekdays[i];


                    weatherImage.style.display = weatherImage.src ? 'block' : 'none';
                }
            } else {
                clearWeatherInfo();
                alert('City not found. Please select a valid city.');
            }
        });
}